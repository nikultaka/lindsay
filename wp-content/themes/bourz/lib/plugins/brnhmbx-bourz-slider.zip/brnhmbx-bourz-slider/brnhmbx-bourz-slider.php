<?php
/*
Plugin Name: Burnhambox - Bourz Slider
Plugin URI: http://www.burnhambox.com
Description: Bourz Slider.
Version: 2.0
Author: Burnhambox
Author URI: http://www.burnhambox.com
License: GNU
*/

/* SLIDER */
function bourz_create_slider_posttype() {

	$labels = array(
		'add_new_item' => 'Add New Slide'
	);

	$args = array(
		'labels' => $labels,
		'public' => false,
		'show_ui' => true,
		'menu_icon' => 'dashicons-images-alt',
		'capability_type' => 'page',
		'rewrite' => array( 'slide-group', 'post_tag' ),
		'label'  => 'Bourz Slider',
		'supports' => array( 'title', 'custom-fields', 'thumbnail', 'page-attributes' ),
	);

	register_post_type( 'slider', $args );

}

add_action( 'init', 'bourz_create_slider_posttype' );

//

function bourz_create_slider_location_tax() {

	register_taxonomy( 'slide-group', 'slider', array(
			'label' => 'Slide Groups',
			'public' => false,
			'show_ui' => true,
			'show_admin_column' => true,
			'rewrite' => false
		)
	);

}

add_action( 'init', 'bourz_create_slider_location_tax' );

//

function bourz_set_default_slidermeta( $post_ID ) {

	add_post_meta( $post_ID, 'Bourz-Slider-URL', 'http://', true );
	add_post_meta( $post_ID, 'Bourz-Slider-Target', '_self', true );
	add_post_meta( $post_ID, 'Bourz-Slider-Excerpt', 'Lorem ipsum dolor sit amet.', true );
	add_post_meta( $post_ID, 'Bourz-Slider-Post-ID', 0, true );

	return $post_ID;

}

add_action( 'wp_insert_post', 'bourz_set_default_slidermeta' );

//

function bourz_getExcerptByID( $post_id ) {

	global $post;
	$save_post = $post;
	$post = get_post( $post_id );
	$output = get_the_excerpt();
	$post = $save_post;
	return $output;

}

//

function bourz_slider_shortcode( $atts = null ) {

	global $add_my_script, $ss_atts;
	$add_my_script = true;
	$ss_atts = shortcode_atts(
		array(
			'group' => '',
			'limit' => -1,
		), $atts, 'bourzslider'
	);

	$args = array(
		'post_type' => 'slider',
		'posts_per_page' => $ss_atts['limit'],
		'orderby' => 'menu_order',
		'order' => 'ASC'
	);

	if ( $ss_atts['group'] != '' ) {

		$args['tax_query'] = array(
			array( 'taxonomy' => 'slide-group', 'field' => 'slug', 'terms' => $ss_atts['group'] )
		);

	}

	$the_query = new WP_Query( $args );
	$slides = array();

	$brnhmbx_bourz_opt_bxControls = get_theme_mod( 'brnhmbx_bourz_opt_bxControls_Main', 'bullet' );
	$brnhmbx_bourz_opt_SliderStyle = get_theme_mod( 'brnhmbx_bourz_opt_SliderStyle', 'b' );
	$brnhmbx_bourz_sliderHeight = get_theme_mod( 'brnhmbx_bourz_sliderHeight', 600 );

	if ( $the_query->have_posts() ) {

		while ( $the_query->have_posts() ) {

			$the_query->the_post();
			$slide_callPost = false;
			$actual_base_ID = get_the_ID();
			$slide_postID = get_post_meta( get_the_ID(), 'Bourz-Slider-Post-ID', true );

			if ( $slide_postID != 0 && $slide_postID != '' ) {

				$actual_base_ID = $slide_postID;
				$url = get_the_permalink( $actual_base_ID );

				if ( get_post_meta( get_the_ID(), 'Bourz-Slider-Excerpt', true ) ) {

					$caption_text = get_post_meta( get_the_ID(), 'Bourz-Slider-Excerpt', true );

				} else {

					$caption_text = bourz_getExcerptByID( $actual_base_ID );

				}

				if ( get_post_thumbnail_id( get_the_ID() ) ) {

					$img_path = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'brnhmbx-bourz-slider-image' );

				} else {

					$img_path = wp_get_attachment_image_src( get_post_thumbnail_id( $actual_base_ID ), 'brnhmbx-bourz-slider-image' );

				}

			} else {

				$url = get_post_meta( get_the_ID(), 'Bourz-Slider-URL', true );
				$caption_text = get_post_meta( get_the_ID(), 'Bourz-Slider-Excerpt', true );
				$img_path = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'brnhmbx-bourz-slider-image' );

			}

			$button_target = get_post_meta( get_the_ID(), 'Bourz-Slider-Target', true );

			$linker_open = '';
			$linker_close = '';
			$padding_if_not_empty = '';

			$slide_image = get_template_directory_uri() . '/css/images/image-placeholder.jpg';
			$header = '';

			$replaceCaptionReadMore = '/\<div class="btnReadMore(.*)\<\/div>/';
			$caption_final_text = preg_replace( $replaceCaptionReadMore, '', $caption_text );

			$caption = '';
			$padding_caption = '';

			$date = '';
			$comment_icon = '';
			$padding_comment_icon = '';
			$categories = '';

			//

			if ( $url != '' && $url != 'http://' ) {

				$linker_open = '<a class="slide-a" href="' . esc_url( $url ) . '" target="' . esc_attr( $button_target ) . '">';
				$linker_close = '</a>';
			}

			//

			if ( $img_path ) {

				$slide_image = $img_path[0];

			}

			//

			if ( get_the_title() ) {

				$header = '<div class="slider-header brnhmbx-font-1 fw700">' . esc_attr( get_the_title() ) . '</div>';
				$padding_caption = 'padding-top: 10px; padding-bottom: 5px;';

			} else {

				if ( get_the_title( $actual_base_ID ) ) {

					$header = '<div class="slider-header brnhmbx-font-1 fw700">' . esc_attr( get_the_title( $actual_base_ID ) ) . '</div>';
					$padding_caption = 'padding-top: 10px; padding-bottom: 5px;';

				}

			}

			//

			if ( $caption_text && get_theme_mod( 'brnhmbx_bourz_bptsCaption', 1 ) ) {

				$caption = '<div class="slider-caption brnhmbx-font-2 fst-italic" style="' . esc_attr( $padding_caption ) . '">' . esc_attr( $caption_final_text ) . '</div>';

			}

			//

			if ( get_theme_mod( 'brnhmbx_bourz_bptsDate', 1 ) ) {

				$date = '<div class="slider-date brnhmbx-font-4 fw700">' . get_the_date( '', $actual_base_ID ) . '</div>';
				$padding_comment_icon = 'margin-left: 30px;';

			}

			//

			if ( get_theme_mod( 'brnhmbx_bourz_bptsComment', 1 ) && comments_open( $actual_base_ID ) ) {

				$comment_icon = '<div class="slider-comment-icon brnhmbx-font-4 fw700" style="' . esc_attr( $padding_comment_icon ) . '"><div class="slider-comment-icon-inner"><i class="fa fa-comment"></i></div><div class="slider-comment-icon-number">' . get_comments_number( $actual_base_ID ) . '</div></div>';

			}

			//

			$categories = '<div class="slider-categories brnhmbx-font-1">';

			$brnhmbx_bourz_categories = get_the_category( $actual_base_ID );
			$brnhmbx_bourz_separator = ', ';
			$brnhmbx_bourz_output = '';

			if ( $brnhmbx_bourz_categories && get_theme_mod( 'brnhmbx_bourz_bptsCategories', 1 ) ) {

				foreach( $brnhmbx_bourz_categories as $brnhmbx_bourz_category ) {

					$brnhmbx_bourz_output .= esc_attr( $brnhmbx_bourz_category->cat_name ) . wp_kses_post( $brnhmbx_bourz_separator );

				}

				$categories .= trim( $brnhmbx_bourz_output, $brnhmbx_bourz_separator );

				$categories .= '</div>';

			} else {

				$categories = '';

			}

			//

			if ( $brnhmbx_bourz_opt_SliderStyle == 'a' ) {

				if ( $caption || $header || $date || $comment_icon || $categories ) { $padding_if_not_empty = ' slide-text-padding'; }

				$slide_info = 'slide-info';

			} else if ( $brnhmbx_bourz_opt_SliderStyle == 'b' || $brnhmbx_bourz_opt_SliderStyle == 'c' ) {

				if ( $caption || $header || $date || $comment_icon || $categories ) { $padding_if_not_empty = ' slide-text-padding-2'; }

				$slide_info = 'slide-info-2';

			}

			//

			$slides[] = '
			<li>' . wp_kses_post( $linker_open ) . '<div class="slide-container" style="background-image: url(' . esc_url( $slide_image ) . '); height: ' . esc_attr( $brnhmbx_bourz_sliderHeight ) . 'px;">
				<div class="slide-info-outer">
                    <div class="' . esc_attr( $slide_info ) . '">
                        <div class="slide-info-inner">
							<div class="slide-text-outer">
								<div class="slide-text' . esc_attr( $padding_if_not_empty ) . '">' . wp_kses_post( $date ) . wp_kses_post( $comment_icon ) . wp_kses_post( $header ) . wp_kses_post( $caption ) . wp_kses_post( $categories ) . '</div>
							</div>
                        </div>
                    </div>
                </div>
			</div>' . wp_kses_post( $linker_close ) . '</li>';

		}

	}

	wp_reset_query();

	return '<div class="bourz-slider-container zig-zag clearfix"><ul class="bxslider-main" style="overflow: hidden; height: ' . esc_attr( $brnhmbx_bourz_sliderHeight ) . 'px;">' . implode( '', $slides ) . '</ul></div>';

}

add_shortcode( 'bourzslider', 'bourz_slider_shortcode' );
/* */
?>
