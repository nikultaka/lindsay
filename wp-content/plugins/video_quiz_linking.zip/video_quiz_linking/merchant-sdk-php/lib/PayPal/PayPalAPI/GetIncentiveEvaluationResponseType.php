<?php
namespace PayPal\PayPalAPI;

use PayPal\EBLBaseComponents\AbstractResponseType;

/**
 *
 */
class GetIncentiveEvaluationResponseType extends AbstractResponseType
{

    /**
     *
     * @access    public
     * @namespace ebl
     * @var \PayPal\EBLBaseComponents\GetIncentiveEvaluationResponseDetailsType
     */
    public $GetIncentiveEvaluationResponseDetails;

}
